-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 20 Ara 2024, 21:27:45
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `calisan_sistemi`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `calisanlar`
--

CREATE TABLE `calisanlar` (
  `id` int(11) NOT NULL,
  `isim` varchar(100) NOT NULL,
  `telefonnumarası` text NOT NULL,
  `pozisyon` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `sifre` varchar(255) NOT NULL,
  `kayit_tarihi` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `calisanlar`
--

INSERT INTO `calisanlar` (`id`, `isim`, `telefonnumarası`, `pozisyon`, `email`, `sifre`, `kayit_tarihi`) VALUES
(66, 'Hatice Şeyma Özdemir', '05555555555', 'Admin', 'admin@techworld.com', '$2y$10$g9v66voFcvIz9rIMQ4Ga8.FoMuVRGiz4tijVU7BRdtE1eY9M12DpK', '2024-12-17 11:31:17'),
(70, 'Yusuf Kocabaş', '05444444444', 'Cyber Security', 'yusuf@techworld.com', '$2y$10$m7f.87UAN9tSrOBe.V9nNuMBTd5CXIvuW2dK5TibUBJdFakbDbNzK', '2024-12-18 08:40:09'),
(72, 'Kadir', '05555555555', 'Developer', 'kadir@techworld.com', '$2y$10$68MsWq.Xqu9w7r1Ta.P9FeI3S3lifxLMyuR7MCODGOuRaFbLcPznO', '2024-12-18 17:36:46');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `katkilar`
--

CREATE TABLE `katkilar` (
  `id` int(11) NOT NULL,
  `bagisci` text DEFAULT NULL,
  `katki_turu` varchar(255) DEFAULT NULL,
  `katki_miktari` decimal(10,2) DEFAULT NULL,
  `tarih` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `katkilar`
--

INSERT INTO `katkilar` (`id`, `bagisci`, `katki_turu`, `katki_miktari`, `tarih`) VALUES
(7, 'admin@techworld.com', 'seyahat', 180.00, '2024-12-17 19:03:06'),
(8, 'admin@techworld.com', 'mutfak', 180.00, '2024-12-17 19:10:31'),
(9, 'admin@techworld.com', 'mutfak', 188.00, '2024-12-17 19:12:00'),
(10, 'admin@techworld.com', 'seyahat', 1.00, '2024-12-17 19:16:00'),
(11, 'admin@techworld.com', 'seyahat', 1.00, '2024-12-17 19:16:13'),
(12, 'admin@techworld.com', 'seyahat', 1.00, '2024-12-17 19:16:42'),
(13, 'admin@techworld.com', 'seyahat', 1.00, '2024-12-17 19:16:54'),
(14, 'admin@techworld.com', 'seyahat', 1.00, '2024-12-17 19:17:18'),
(15, 'kadir@techworld.com|Kadir', 'bagis', 11.00, '2024-12-17 19:27:36'),
(16, 'admin@techworld.com|Kadir', 'bagis', 11.00, '2024-12-17 19:27:45'),
(17, 'kadir@techworld.com', 'ofis', 11.00, '2024-12-17 19:27:56'),
(18, 'admin@techworld.com', 'malzeme', 121.00, '2024-12-17 19:32:41'),
(19, 'admin@techworld.com', 'ofis', 11.00, '2024-12-17 19:34:41'),
(20, 'admin@techworld.com', 'ofis', 12.00, '2024-12-17 19:35:36'),
(21, 'admin@techworld.com', 'ofis', 13.00, '2024-12-17 19:35:56'),
(22, 'admin@techworld.com', 'ofis', 14.00, '2024-12-17 19:36:44'),
(23, 'admin@techworld.com', 'ofis', 15.00, '2024-12-17 19:37:11'),
(24, 'admin@techworld.com', 'mutfak', 11.00, '2024-12-18 08:16:12'),
(25, 'yusuf@techworld.com', 'bagis', 9.00, '2024-12-18 08:41:32'),
(26, 'yusuf@techworld.com', 'bagis', 958.00, '2024-12-18 08:41:46'),
(27, 'admin@techworld.com', 'bagis', 958.00, '2024-12-18 08:42:43'),
(28, 'admin@techworld.com', 'mutfak', 958.00, '2024-12-18 08:44:16'),
(29, 'admin@techworld.com', 'malzeme', 111.00, '2024-12-18 08:48:01'),
(30, 'admin@techworld.com', 'seyahat', 1234.00, '2024-12-18 08:51:50'),
(31, 'admin@techworld.com', 'mutfak', 12345.00, '2024-12-18 08:52:19'),
(32, 'admin@techworld.com', 'seyahat', 11.00, '2024-12-18 08:52:39'),
(33, 'admin@techworld.com', 'seyahat', 2222.00, '2024-12-18 08:53:13'),
(34, 'admin@techworld.com', 'seyahat', 11.00, '2024-12-18 08:53:49'),
(35, 'admin@techworld.com', 'mutfak', 8888.00, '2024-12-18 08:54:09'),
(36, 'admin@techworld.com', 'seyahat', 1.00, '2024-12-18 08:56:15'),
(37, 'admin@techworld.com', 'ofis', 1000.00, '2024-12-18 13:23:00'),
(38, 'kadir@techworld.com', 'ofis', 1000.00, '2024-12-18 17:18:22'),
(39, 'kadir@techworld.com', 'malzeme', 2000.00, '2024-12-18 17:38:17');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `calisanlar`
--
ALTER TABLE `calisanlar`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Tablo için indeksler `katkilar`
--
ALTER TABLE `katkilar`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `calisanlar`
--
ALTER TABLE `calisanlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- Tablo için AUTO_INCREMENT değeri `katkilar`
--
ALTER TABLE `katkilar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
