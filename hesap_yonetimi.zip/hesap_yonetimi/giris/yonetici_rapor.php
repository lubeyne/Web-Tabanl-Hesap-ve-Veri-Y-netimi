<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'Admin') {
    header("Location: logintam.html");
    exit();
}
require_once 'config.php';
$activePage = 'rapor';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Rapor Sayfası</title>
  <link rel="stylesheet" href="yonetici_rapor.css?v=<?php echo time(); ?>">
</head>
<body>
    <!-- Hamburger Menü İkonu -->
    <div class="menu-toggle" onclick="toggleMenu()">
      <span class="bar"></span>
      <span class="bar"></span>
      <span class="bar"></span>
    </div>

      <!-- Açılır Menü -->
<div class="sidebar" id="sidebar">
  <?php include 'sidebar.php'; ?>
</div>

    
  <!-- Üst Çubuk -->
  <div class="header">
    <img src="logo.png" alt="Logo">
  </div>

  <!-- Sayfa İçeriği -->
  <div class="content">

    <!-- Sol Dikdörtgen -->
    <div class="left-box">
      <h2>Bütçe Durumu</h2>
      <div class="progress-bar-container">
        <div class="progress-bar"></div>
      </div>
      <div class="budget-display">Toplam Bütçe: <span id="budget">0</span> TL</div>

      <!-- Genel Grafik -->
      <div class="chart-container">
        <h3>Genel Harcama Sütun Grafiği</h3>
        <canvas id="general-chart"></canvas>
      </div>
    </div>

    <!-- Sağ Dikdörtgen -->
<div class="right-box">
  <h2>Katkı Yapan Kullanıcılar</h2>
  <div class="user-list">
    <table>
      <thead>
        <tr>
          <th>Bağışçı</th>
          <th>Katkı Türü</th>
          <th>Katkı Miktarı (TL)</th>
        </tr>
      </thead>
      <tbody>
        <?php
        // $conn bağlantısı config.php ile sağlanmıştır.

        // Tüm kullanıcıları çekme sorgusu
        $result = $conn->query("SELECT bagisci, katki_turu, katki_miktari FROM katkilar");

        if ($result->num_rows > 0) {
            // Her bir kullanıcıyı tabloya ekle
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['bagisci']) . "</td>";
                echo "<td>" . htmlspecialchars($row['katki_turu']) . "</td>";
                echo "<td>" . htmlspecialchars($row['katki_miktari']) . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='3' style='text-align: center;'>Katkı yapan kullanıcı bulunamadı.</td></tr>";
        }

        // Katki türüne göre miktarların toplamını hesapla
        $sumResult = $conn->query("SELECT katki_turu, SUM(katki_miktari) AS toplam_miktar FROM katkilar GROUP BY katki_turu");
        $katkiToplamlari = [];

        if ($sumResult->num_rows > 0) {
            while ($sumRow = $sumResult->fetch_assoc()) {
                $katkiToplamlari[$sumRow['katki_turu']] = $sumRow['toplam_miktar'];
            }
        }

        // Ayrı değişkenlere atama
        $mutfakToplam = isset($katkiToplamlari['mutfak']) ? $katkiToplamlari['mutfak'] : 0;
        $seyahatToplam = isset($katkiToplamlari['seyahat']) ? $katkiToplamlari['seyahat'] : 0;
        $malzemeToplam = isset($katkiToplamlari['malzeme']) ? $katkiToplamlari['malzeme'] : 0;
        $ofisToplam = isset($katkiToplamlari['ofis']) ? $katkiToplamlari['ofis'] : 0;
        $bagisToplam = isset($katkiToplamlari['bagis']) ? $katkiToplamlari['bagis'] : 0;

        // Veritabanı bağlantısını kapat
        $conn->close();
        ?>
      </tbody>
    </table>
  </div>

  <!-- Katkı Türü Toplamları -->
  <div class="katki-summary">
    <h3>Katkı Türüne Göre Toplamlar</h3>
    <ul>
      <?php
      $turIsimleri = [
          'mutfak' => '🍳 Mutfak Giderleri',
          'seyahat' => '✈️ Seyahat ve Ulaşım',
          'malzeme' => '💻 Ekipman ve Malzeme',
          'ofis' => '🏢 Ofis Giderleri',
          'bagis' => '🤝 Bağış ve Yardımlar'
      ];
      foreach ($katkiToplamlari as $tur => $toplam) {
          $label = isset($turIsimleri[$tur]) ? $turIsimleri[$tur] : htmlspecialchars($tur);
          echo "<li><span class='summary-type'>$label</span><span class='summary-amount'>$toplam TL</span></li>";
      }
      ?>
    </ul>
  </div>

  <!-- JavaScript -->

  <script>
    function toggleMenu() {
        var sidebar = document.getElementById('sidebar');
        var toggle = document.querySelector('.menu-toggle');
        sidebar.classList.toggle('active');
        toggle.classList.toggle('active');
    }
  </script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>


    $mutfaktoplam = <?php echo $mutfakToplam; ?>;
    $seyahattoplam = <?php echo $seyahatToplam; ?>;
    $malzemetoplam = <?php echo $malzemeToplam; ?>;
    $ofistoplam = <?php echo $ofisToplam; ?>;
    $bagistoplam = <?php echo $bagisToplam; ?>;
    $toplamdeger = $mutfaktoplam + $seyahattoplam + $malzemetoplam + $ofistoplam + $bagistoplam;
    // Bütçe animasyonu
    let totalBudget = $toplamdeger; // Örnek değer
    let display = document.getElementById("budget");
    let counter = 0;
    let interval = setInterval(() => {
      if (counter < totalBudget) {
        counter += Math.max(1, Math.ceil(totalBudget / 20)); // Dinamik adım hızı
        if (counter > totalBudget) counter = totalBudget;
        display.textContent = counter;
      } else {
        clearInterval(interval);
        // İlerlemeyi ata
        const targetBudgetLimit = 50000;
        const progressPercent = Math.min((totalBudget / targetBudgetLimit) * 100, 100);
        document.querySelector('.progress-bar').style.width = progressPercent + '%';
      }
    }, 50);



    // Genel Harcama Grafiği //
    const generalCtx = document.getElementById('general-chart').getContext('2d');
    const generalChart = new Chart(generalCtx, {
      type: 'bar',
      data: {
        labels: ['Bağış', 'Malzeme', 'Mutfak', 'Ofis', 'Seyahat'], // Örnek aylar
        datasets: [{
          label: 'Harcama (TL)', // Bu etiketin rengini beyaz yapıyoruz
          data: [$bagistoplam, $malzemetoplam, $mutfaktoplam, $ofistoplam, $seyahattoplam], // Örnek harcama verileri
          backgroundColor: 'rgba(44, 73, 143, 0.85)', 
          borderColor: 'white',  // Çizgileri beyaz yap
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        scales: {
          x: {
            ticks: {
              color: 'white' // X eksenindeki ay isimlerini beyaz yapar
            }
          },
          y: {
            ticks: {
              color: 'white', // Y eksenindeki sayıları beyaz yapar
              beginAtZero: true // Y ekseni sıfırdan başlar
            }
          }
        },
        plugins: {
          legend: {
            labels: {
              color: 'white' // Etiketlerin rengini beyaz yapar
            }
          }
        }
      }
    });
  </script>
</body>
</html>
