<?php
require_once 'config.php';

// Form verilerini al
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Veritabanındaki e-posta ile şifreyi kontrol et
    $sql = "SELECT * FROM calisanlar WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email); // E-posta değerini bağla
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // Şifreyi doğrula
        if (password_verify($password, $user['sifre'])) {
            session_start();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_name'] = $user['isim'];
            $_SESSION['user_role'] = $user['pozisyon'];
            
            // Geriye dönük uyumluluk sağlamak adına
            $_SESSION['kontrolmail'] = $user['email'];

            if ($user['pozisyon'] === 'Admin') {
                header("Location: yonetici_rapor.php");
            } else {
                header("Location: calisan_anasayfa.php");
            }
            exit();
        } else {
            echo "<script>alert('Hatalı şifre!'); window.location.href='logintam.html';</script>";
        }
    } else {
        echo "<script>alert('E-posta bulunamadı!'); window.location.href='logintam.html';</script>";
    }
    $stmt->close();
}
$conn->close();
?>
