<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'Admin') {
    die("Yetkisiz erişim.");
}
require_once 'config.php';

// GET ile gelen e-posta adresini kontrol et
if (isset($_GET['email']) && filter_var($_GET['email'], FILTER_VALIDATE_EMAIL)) {
    $email = $conn->real_escape_string($_GET['email']);

    // Kullanıcıyı silen SQL sorgusu
    $deleteSql = "DELETE FROM calisanlar WHERE email = ?";
    $stmt = $conn->prepare($deleteSql);
    $stmt->bind_param("s", $email);

    if ($stmt->execute()) {
        echo "Kullanıcı başarıyla silindi.";
    } else {
        echo "Silme işlemi başarısız: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Geçersiz veya eksik e-posta adresi.";
}

$conn->close();
?>
