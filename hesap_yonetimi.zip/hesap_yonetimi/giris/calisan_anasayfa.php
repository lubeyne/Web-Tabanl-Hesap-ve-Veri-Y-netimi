<?php
// Session başlatıyoruz
session_start();

require_once 'config.php';

// Eğer session'da 'user_email' veya 'kontrolmail' yoksa, giriş sayfasına yönlendir
if (!isset($_SESSION['user_email']) && !isset($_SESSION['kontrolmail'])) {
    header("Location: logintam.html");
    exit();
}
$activePage = 'anasayfa';

// E-posta adresini alıyoruz
$email = isset($_SESSION['user_email']) ? $_SESSION['user_email'] : $_SESSION['kontrolmail'];

// E-posta adresine göre katkıları sorguluyoruz
$sql = "SELECT * FROM katkilar WHERE bagisci = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);  // E-posta değerini bağlıyoruz
$stmt->execute();
$result = $stmt->get_result();

// Bağışları listeleme
$contributions = [];
while ($row = $result->fetch_assoc()) {
    $contributions[] = $row;
}

// Toplam katkı miktarını hesaplıyoruz
$total_contribution = 0;
foreach ($contributions as $contribution) {
    $total_contribution += $contribution['katki_miktari'];
}

// Bağlantıyı kapatıyoruz
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Çalışan Anasayfası</title>
    <link rel="stylesheet" href="calisan_anasayfa.css?v=<?php echo time(); ?>">
</head>
<body>
    <!-- Hamburger Menü İkonu -->
    <div class="menu-toggle" onclick="toggleMenu()">
        <span class="bar"></span>
        <span class="bar"></span>
        <span class="bar"></span>
    </div>

    <!-- Sol Dikdörtgen -->
    <div class="left-rectangle">
        <!-- Hızlı Özet Başlığı -->
        <div class="quick-summary-title">Hızlı Özet</div>
        
        <!-- Hızlı Özetin Altındaki Dikdörtgen -->
        <div class="total-contribution-box">
            <div class="total-contribution-title">Toplam Katkı</div>
            <div class="total-contribution-amount"><?php echo $total_contribution; ?> TL</div>
        </div>
    </div>

    <!-- Sağ Dikdörtgen -->
    <div class="right-rectangle">
        <div class="contributions-title">Katkılarım</div>

        <!-- Katkılarım Altındaki Tablo -->
        <div class="contributions-box">
            <table class="contributions-table">
                <thead>
                    <tr>
                        <th>Tutar</th>
                        <th>Tarih</th>
                        <th>Tür</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($contributions)): ?>
                        <tr>
                            <td colspan="3">Henüz herhangi bir bağışınız bulunmamaktadır.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($contributions as $contribution): ?>
                            <tr>
                                <td><?php echo $contribution['katki_miktari']; ?> TL</td>
                                <td><?php echo $contribution['tarih']; ?></td>
                                <td><?php echo $contribution['katki_turu']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Açılır Menü -->
    <div class="sidebar" id="sidebar">
        <?php include 'sidebar.php'; ?>
    </div>

    <!-- Üst Çubuk (Logo Ortalanmış) -->
    <div class="header">
        <img src="logo.png" alt="Logo">
    </div>

    <script>
        function toggleMenu() {
            var sidebar = document.getElementById('sidebar');
            var toggle = document.querySelector('.menu-toggle');
            sidebar.classList.toggle('active');
            toggle.classList.toggle('active');
        }

        function fetchUserName(email) {
            // AJAX sorgusu ile veritabanından kullanıcı ismini çekme
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'fetch_user_name.php?email=' + email, true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var userName = xhr.responseText;
                    document.querySelector('.profile-name').innerHTML = userName + '<br>Yazılımcı';
                }
            };
            xhr.send();
        }

        // Kullanıcının e-posta adresini alıp kullanıcı adını çekmek
        var userEmail = 'user@example.com'; // Giriş yapan kullanıcının e-posta adresi
        fetchUserName(userEmail);

    </script>
</body>
</html>
