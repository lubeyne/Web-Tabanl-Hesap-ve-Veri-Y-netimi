<?php
session_start();
if (!isset($_SESSION['user_email']) && !isset($_SESSION['kontrolmail'])) {
    header("Location: logintam.html");
    exit();
}
require_once 'config.php';
require_once 'mail_helper.php';
$activePage = 'katki';

// SQL sorgusu ile isim ve email verilerini al
$sql = "SELECT isim, email FROM calisanlar";
$result = $conn->query($sql);

// Dropdown için seçenekleri oluştur
$options = "";
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $options .= "<option value='" . htmlspecialchars($row['email']) . "'>" . htmlspecialchars($row['isim']) . "</option>";
    }
} else {
    $options = "<option value=''>Kayıt bulunamadı</option>";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['expense-type']) && isset($_POST['amount']) && isset($_POST['card-number']) && isset($_POST['expiry-date']) && isset($_POST['cvv'])) {
        $bagisci = $_POST['currency'];
        $expenseType = $_POST['expense-type'];
        $amount = $_POST['amount'];
        $cardNumber = trim($_POST['card-number']);
        $expiryDate = trim($_POST['expiry-date']);
        $cvv = trim($_POST['cvv']);
        
        // Mantıksal doğrulama: Kart bilgileri dolu mu?
        if (strlen($cardNumber) < 16 || strlen($expiryDate) < 5 || strlen($cvv) < 3) {
            echo '<script type="text/javascript"> window.onload = function () { alert("Lütfen kart bilgilerini eksiksiz doldurunuz!"); } </script>';
        } else {
            // 1. Veriyi kaydetme
            $stmt = $conn->prepare("INSERT INTO katkilar (bagisci, katki_turu, katki_miktari) VALUES (?, ?, ?)");
            $stmt->bind_param("ssi", $bagisci, $expenseType, $amount);

            if ($stmt->execute()) {
                // 2. Aynı tabloda bagisci alanına göre isim alanını sorgulama
                $query = $conn->prepare("SELECT isim FROM calisanlar WHERE email = ?");
                $query->bind_param("s", $bagisci);
                $query->execute();
                $result = $query->get_result();

                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $isim = $row['isim']; // isim alanını değişkene atama
                } else {
                    $isim = "Değer Bulunamadı";
                }
                $query->close();

                // mail_helper.php'deki sendEmail fonksiyonu ile teşekkür e-postası gönder
                $subject = "Katkiniz Icin Tesekkurler";
                $body = "
                    <p>Merhaba <strong>{$isim}</strong>,</p>
                    <p> Bir kez daha biz olduğumuzu hissettirip şirket içi organizasyonlarımıza <strong>{$amount} TL</strong>
                    tutarında katkı sağladığınız için teşekkür ederiz. <br></br>
                    <strong>TechWorld Şirketi Adına Tüm Çalışanlarımız</strong></p>
                ";
                
                $mail_status = sendEmail($bagisci, $subject, $body);
                if ($mail_status === true) {
                    echo '<script type="text/javascript"> window.onload = function () { alert("Katkınız kaydedildi ve Teşekkür E-Postası gönderildi!"); window.location.href="calisan_anasayfa.php"; } </script>';
                } else {
                    echo '<script type="text/javascript"> window.onload = function () { alert("Katkınız kaydedildi ancak e-posta gönderilemedi. Hata: ' . addslashes($mail_status) . '"); window.location.href="calisan_anasayfa.php"; } </script>';
                }
            } else {
                echo '<script type="text/javascript"> window.onload = function () { alert("Hata: ' . addslashes($stmt->error) . '"); } </script>';
            }
            $stmt->close();
        }
        $conn->close();
    } else {
        echo '<script type="text/javascript"> window.onload = function () { alert("Lütfen formdaki tüm alanları doldurun."); } </script>';
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harcama & Katkı Sayfası</title>
    <link rel="stylesheet" href="calisan_katki.css?v=<?php echo time(); ?>">
</head>
<body>
    <!-- Hamburger Menü İkonu -->
    <div class="menu-toggle" onclick="toggleMenu()">
        <span class="bar"></span>
        <span class="bar"></span>
        <span class="bar"></span>
    </div>

    <!-- Tek Bir Form Yapısı -->
    <form method="POST" id="contributionForm">
        <div class="container">
            <!-- Sol Dikdörtgen (Kategori ve Miktar) -->
            <div class="left-rectangle">
                <h1 style="color: white; margin-bottom: 20px; font-size: 24px; text-shadow: 1px 1px 3px rgba(0,0,0,0.5);">Katkı Kategorisi</h1>
                
                <!-- Radio Butonlar -->
                <div class="radio-group">
                    <label class="radio-card">
                        <input type="radio" name="expense-type" value="mutfak" required>
                        <span class="radio-label">🍳 Mutfak Giderleri</span>
                    </label>
                    <label class="radio-card">
                        <input type="radio" name="expense-type" value="seyahat">
                        <span class="radio-label">✈️ Seyahat ve Ulaşım</span>
                    </label>
                    <label class="radio-card">
                        <input type="radio" name="expense-type" value="malzeme">
                        <span class="radio-label">💻 Ekipman ve Malzeme</span>
                    </label>
                    <label class="radio-card">
                        <input type="radio" name="expense-type" value="ofis">
                        <span class="radio-label">🏢 Ofis Giderleri</span>
                    </label>
                    <label class="radio-card">
                        <input type="radio" name="expense-type" value="bagis">
                        <span class="radio-label">🤝 Bağış ve Yardımlar</span>
                    </label>
                </div>

                <!-- Katkı Miktarı ve Çalışan Seçimi -->
                <div class="contribution-amount">
                    <label for="amount">Katkı Yapmak İstediğiniz Miktar (TL):</label>
                    <input type="number" id="amount" name="amount" class="custom-input" min="1" required placeholder="Örn: 500">
                    
                    <label for="currency" style="margin-top: 15px;">Katkı Yapan Çalışan:</label>
                    <select id="currency" name="currency" class="custom-select" required>
                        <?php echo $options; ?> <!-- Çalışan listesi -->
                    </select>
                </div>
            </div>
        
            <!-- Sağ Dikdörtgen (Kart Bilgileri ve Sanal Kart) -->
            <div class="right-rectangle">
                <h1 style="color: white; text-align: center; margin-bottom: 20px; font-size: 24px; text-shadow: 1px 1px 3px rgba(0,0,0,0.5);">Kart Bilgileri</h1>
                
                <!-- Etkileşimli Sanal Kart Görseli -->
                <div class="virtual-card-wrapper">
                    <div class="virtual-card">
                        <div class="card-front">
                            <div class="card-chip"></div>
                            <div class="card-number-display" id="cardNoDisplay">•••• •••• •••• ••••</div>
                            <div class="card-info-row">
                                <div class="card-holder">
                                    <div class="card-label">KART SAHİBİ</div>
                                    <div class="card-value" id="cardHolderDisplay">ÇALIŞAN ADI</div>
                                </div>
                                <div class="card-expiry">
                                    <div class="card-label">SON KUL.</div>
                                    <div class="card-value" id="cardExpiryDisplay">MM/YY</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card-inputs">
                    <!-- Kart Numarası -->
                    <label for="card-number">Kart Numarası:</label>
                    <input type="text" id="card-number" name="card-number" minlength="16" maxlength="16" placeholder="1234567890123456" required pattern="\d{16}" title="Lütfen 16 haneli kart numaranızı boşluksuz girin.">
        
                    <!-- Son Kullanma Tarihi -->
                    <label for="expiry-date">Son Kullanma Tarihi:</label>
                    <input type="text" id="expiry-date" name="expiry-date" maxlength="5" placeholder="MM/YY" required pattern="(0[1-9]|1[0-2])\/\d{2}" title="Lütfen MM/YY formatında girin. Örn: 12/28">
        
                    <!-- CVV -->
                    <label for="cvv">CVV (Güvenlik Kodu):</label>
                    <input type="text" id="cvv" name="cvv" minlength="3" maxlength="3" placeholder="123" required pattern="\d{3}" title="Lütfen 3 haneli güvenlik kodunu girin.">
                </div>
            </div>
        </div>

        <!-- Katkı Yap Butonu (Orta Alt Bölüm) -->
        <div class="submit-container" style="text-align: center; margin-top: 30px; margin-bottom: 50px;">
            <button type="submit" class="submit-button">Katkıyı Onayla ve Ödemeyi Yap</button>
        </div>
    </form>

    <!-- Açılır Menü -->
    <div class="sidebar" id="sidebar">
        <?php include 'sidebar.php'; ?>
    </div>

    <!-- Üst Çubuk (Logo Ortalanmış) -->
    <div class="header">
        <img src="logo.png" alt="Logo">
    </div>

    <script>
        function toggleMenu() {
            var sidebar = document.getElementById('sidebar');
            var toggle = document.querySelector('.menu-toggle');
            sidebar.classList.toggle('active');
            toggle.classList.toggle('active');
        }

        // Kart numarası alanına sadece rakam girişi ve sanal karta canlı yansıtma
        document.getElementById('card-number').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, ''); // Sadece sayı
            e.target.value = value;
            
            let display = value || '••••••••••••••••';
            let formatted = display.match(/.{1,4}/g)?.join(' ') || '•••• •••• •••• ••••';
            document.getElementById('cardNoDisplay').innerText = formatted;
        });

        // Son kullanma tarihini MM/YY şeklinde maskeleme ve sanal karta canlı yansıtma
        document.getElementById('expiry-date').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, ''); // Sadece sayı
            if (value.length > 2) {
                value = value.substring(0,2) + '/' + value.substring(2,4);
            }
            e.target.value = value;
            document.getElementById('cardExpiryDisplay').innerText = value || 'MM/YY';
        });

        // CVV sayı kontrolü
        document.getElementById('cvv').addEventListener('input', function(e) {
            e.target.value = e.target.value.replace(/\D/g, '');
        });

        // Çalışan dropdown'ı değiştikçe sanal kart sahibini güncelleme
        const selectEmployee = document.getElementById('currency');
        function updateCardHolder() {
            if(selectEmployee.selectedIndex >= 0) {
                const selectedText = selectEmployee.options[selectEmployee.selectedIndex].text;
                document.getElementById('cardHolderDisplay').innerText = selectedText.toUpperCase();
            }
        }
        selectEmployee.addEventListener('change', updateCardHolder);
        
        // Sayfa ilk açıldığında çalıştır
        window.addEventListener('DOMContentLoaded', updateCardHolder);
    </script>
</body>
</html>
