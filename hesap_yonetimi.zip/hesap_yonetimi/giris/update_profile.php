<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Yetkisiz erişim.']);
    exit();
}

require_once 'config.php';

// Gelen JSON verisini al
$data = json_decode(file_get_contents('php://input'), true);

$kullanici_id = $_SESSION['user_id'];
$ad = trim($data['ad']);
$eposta = trim($data['eposta']);
$telefon = trim($data['telefon']);
$pozisyon = trim($data['pozisyon']);
$sifre = isset($data['sifre']) ? trim($data['sifre']) : '';

if (empty($ad) || empty($eposta)) {
    echo json_encode(['success' => false, 'message' => 'Ad ve E-Posta alanları boş bırakılamaz.']);
    exit();
}

// Şifre güncellenecek mi kontrol et
if (!empty($sifre)) {
    $hashedSifre = password_hash($sifre, PASSWORD_BCRYPT);
    $stmt = $conn->prepare("UPDATE calisanlar SET isim = ?, email = ?, telefonnumarası = ?, pozisyon = ?, sifre = ? WHERE id = ?");
    $stmt->bind_param("sssssi", $ad, $eposta, $telefon, $pozisyon, $hashedSifre, $kullanici_id);
} else {
    $stmt = $conn->prepare("UPDATE calisanlar SET isim = ?, email = ?, telefonnumarası = ?, pozisyon = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $ad, $eposta, $telefon, $pozisyon, $kullanici_id);
}

if ($stmt->execute()) {
    // Session'daki bilgileri de güncelleyelim
    $_SESSION['user_name'] = $ad;
    $_SESSION['user_email'] = $eposta;
    $_SESSION['kontrolmail'] = $eposta;
    $_SESSION['user_role'] = $pozisyon;
    
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Veritabanı güncelleme hatası: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
