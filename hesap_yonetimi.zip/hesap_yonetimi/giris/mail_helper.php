<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once 'config.php';
require_once 'vendor/autoload.php';

function sendEmail($to, $subject, $body) {
    $mail = new PHPMailer(true);

    try {
        // SMTP ayarları
        $mail->isSMTP();
        $mail->Host = SMTP_HOST; // SMTP sunucusu
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USER; // Gönderici e-posta adresi
        $mail->Password = SMTP_PASS; // E-posta şifresi veya uygulama şifresi
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Şifreleme türü
        $mail->Port = SMTP_PORT; // SMTP portu

        // Gönderici ve alıcı bilgileri
        $mail->setFrom(SMTP_FROM, SMTP_FROM_NAME);
        $mail->addAddress($to); // Alıcı adresi

        // E-posta içeriği
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8'; // Türkçe karakter sorunu olmaması için charset ekleyelim
        $mail->Subject = $subject;
        $mail->Body = $body;

        // E-postayı gönder
        $mail->send();
        return true; // Başarılı ise true döndür
    } catch (Exception $e) {
        return "E-posta gönderilemedi. Hata: {$mail->ErrorInfo}";
    }
}
?>
