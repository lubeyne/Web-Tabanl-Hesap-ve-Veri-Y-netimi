<?php
session_start();
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'Admin') {
    header("Location: logintam.html");
    exit();
}
require_once 'config.php';
require_once 'mail_helper.php';
$activePage = 'calisan_ekle';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Çalışan Ekle</title>
  <link rel="stylesheet" href="calisan_ekle.css?v=<?php echo time(); ?>">
</head>
<body>

  <!-- Hamburger Menü İkonu -->
  <div class="menu-toggle" onclick="toggleMenu()">
    <span class="bar"></span>
    <span class="bar"></span>
    <span class="bar"></span>
  </div>

  <!-- Açılır Menü -->
  <div class="sidebar" id="sidebar">
    <?php include 'sidebar.php'; ?>
  </div>

  <!-- Üst Çubuk -->
  <div class="header">
    <img src="logo.png" alt="Logo">
  </div>

  <!-- Ana İçerik -->
  <div class="content" id="user-management-content">
    <!-- Kullanıcı Ekle Formu -->
    <div class="form-container">
      <h2>Kullanıcı Ekle</h2>
      <form id="userForm" method="POST" action="calisan_ekle.php">
        <div class="form-group">
          <label for="isim">İsim:</label>
          <input type="text" id="isim" name="isim" placeholder="isim" required>
        </div>
        <div class="form-group">
          <label for="email">E-posta:</label>
          <input type="email" id="email" name="email" placeholder="email" required>
        </div>
        <div class="form-group">
          <label for="telefonnumarası">Telefon Numarası:</label>
          <input type="text" id="telefonnumarası" name="telefonnumarası" placeholder="telefonnumarası" required>
        </div>
        <div class="form-group">
          <label for="pozisyon">Pozisyon</label>
          <input type="text" id="pozisyon" name="pozisyon" placeholder="pozisyon" required>
        </div>
        <button type="submit">Kullanıcı Ekle</button>
      </form>
    </div>

    <!-- Kullanıcı Listesi -->
    <div class="user-list">
      <h2>Tüm Kullanıcılar</h2>
      <div class="user-table-box">
        <table id="userTable">
          <thead>
            <tr>
              <th>İsim</th>
              <th>E-posta</th>
              <th>Telefon</th>
              <th>Pozisyon</th>
              <th>İşlem</th>
            </tr>
          </thead>
          <tbody>
          <?php
              // Tüm kullanıcıları çekme sorgusu
              $result = $conn->query("SELECT isim, email, telefonnumarası, pozisyon FROM calisanlar");

              if ($result && $result->num_rows > 0) {
                  // Her bir kullanıcıyı tabloya ekle
                  while ($row = $result->fetch_assoc()) {
                      echo "<tr>";
                      echo "<td>" . htmlspecialchars($row['isim']) . "</td>";
                      echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                      echo "<td>" . htmlspecialchars($row['telefonnumarası']) . "</td>";
                      echo "<td>" . htmlspecialchars($row['pozisyon']) . "</td>";
                      echo "<td><button class='delete-btn' onclick=\"deleteUserByEmail('" . htmlspecialchars($row['email']) . "')\">Sil</button></td>";
                      echo "</tr>";
                  }
              } else {
                  echo "<tr><td colspan='5'>Kullanıcı bulunamadı.</td></tr>";
              }

            // Form gönderildiğinde eklenecek kullanıcı işlemleri
            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['isim']) && isset($_POST['email'])) {
                $isim = $conn->real_escape_string(trim($_POST['isim']));
                $email = $conn->real_escape_string(trim($_POST['email']));
                $telefonnumarası = $conn->real_escape_string(trim($_POST['telefonnumarası']));
                $pozisyon = $conn->real_escape_string(trim($_POST['pozisyon']));

                // E-posta formatını doğrula
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    echo "<script>alert('Lütfen geçerli bir e-posta adresi giriniz.');</script>";
                } else {
                    // Rastgele şifre oluştur
                    function randomPassword($length = 8) {
                        $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()';
                        return substr(str_shuffle($characters), 0, $length);
                    }

                    $sifre = randomPassword(); // Rastgele şifre oluştur
                    $hashedSifre = password_hash($sifre, PASSWORD_BCRYPT); // Şifreyi hash'le

                    // E-posta adresinin zaten var olup olmadığını kontrol et
                    $check_sql = "SELECT id FROM calisanlar WHERE email = ?";
                    $stmt = $conn->prepare($check_sql);
                    $stmt->bind_param("s", $email);
                    $stmt->execute();
                    $stmt->store_result();

                    if ($stmt->num_rows > 0) {
                        echo "<script>alert('Bu e-posta adresi zaten mevcut. Lütfen başka bir e-posta adresi kullanın.');</script>";
                        $stmt->close();
                    } else {
                        $stmt->close();

                        // Çalışanı veritabanına ekle
                        $insert_sql = "INSERT INTO calisanlar (isim, telefonnumarası, pozisyon, email, sifre) VALUES (?, ?, ?, ?, ?)";
                        $stmt = $conn->prepare($insert_sql);
                        $stmt->bind_param("sssss", $isim, $telefonnumarası, $pozisyon, $email, $hashedSifre);
                        
                        if ($stmt->execute()) {
                            // mail_helper.php'deki sendEmail fonksiyonu ile şifreyi gönder
                            $subject = "Sisteme Giris Sifreniz";
                            $body = "
                                <p>Merhaba <strong>$isim</strong>,</p>
                                <p>Sisteme giriş yapabilmeniz için geçici şifreniz oluşturulmuştur:</p>
                                <p>Şifre: <strong>$sifre</strong></p>
                                <p>Lütfen bu şifreyi kimseyle paylaşmayın.</p>
                            ";
                            
                            $mail_status = sendEmail($email, $subject, $body);
                            
                            if ($mail_status === true) {
                                echo "<script>alert('Çalışan başarıyla eklendi ve şifre e-posta ile gönderildi.'); window.location.href='calisan_ekle.php';</script>";
                            } else {
                                echo "<script>alert('Çalışan eklendi ancak e-posta gönderilemedi. Hata: " . addslashes($mail_status) . "'); window.location.href='calisan_ekle.php';</script>";
                            }
                        } else {
                            echo "<script>alert('Hata: " . addslashes($stmt->error) . "');</script>";
                        }
                    }
                }
            }
        ?>
        </tbody>
      </table>
      </div>
    </div>
  </div>

  <script>
    // Menü açma/kapama fonksiyonu
    function toggleMenu() {
        var sidebar = document.getElementById('sidebar');
        var toggle = document.querySelector('.menu-toggle');
        sidebar.classList.toggle('active');
        toggle.classList.toggle('active');
    }

    function deleteUserByEmail(email) {
        if (confirm("Bu kullanıcıyı silmek istediğinizden emin misiniz?")) {
            fetch(`delete_user.php?email=${encodeURIComponent(email)}`, { method: 'GET' })
                .then(response => response.text())
                .then(data => {
                    alert(data); // Geri dönüş mesajını göster
                    location.reload(); // Sayfayı yenile
                })
                .catch(error => {
                    console.error('Hata:', error);
                    alert("Kullanıcı silinemedi.");
                });
        }
    }
  </script>
</body>
</html>