<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$isAdmin = isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'Admin';
$activePage = isset($activePage) ? $activePage : '';
?>
<ul>
    <?php if ($isAdmin): ?>
        <li><a href="yonetici_rapor.php" class="<?php echo ($activePage === 'rapor') ? 'active' : ''; ?>">Rapor</a></li>
        <li><a href="calisan_ekle.php" class="<?php echo ($activePage === 'calisan_ekle') ? 'active' : ''; ?>">Çalışan Ekle</a></li>
    <?php else: ?>
        <li><a href="calisan_anasayfa.php" class="<?php echo ($activePage === 'anasayfa') ? 'active' : ''; ?>">Anasayfa</a></li>
        <li><a href="calisan_katki.php" class="<?php echo ($activePage === 'katki') ? 'active' : ''; ?>">Katkı Yap</a></li>
    <?php endif; ?>
    <li><a href="kullanicibilgi.php" class="<?php echo ($activePage === 'bilgilerim') ? 'active' : ''; ?>">Bilgilerim</a></li>
    <li><a href="logintam.html" class="logout-btn">Çıkış Yap</a></li>
</ul>
