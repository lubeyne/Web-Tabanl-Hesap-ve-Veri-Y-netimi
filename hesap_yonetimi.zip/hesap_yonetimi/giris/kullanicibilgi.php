<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: logintam.html");
    exit();
}
require_once 'config.php';
$activePage = 'bilgilerim';

// Oturumdaki kullanıcının ID'sine göre bilgi çek
$kullanici_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT isim, email, telefonnumarası, pozisyon FROM calisanlar WHERE id = ?");
$stmt->bind_param("i", $kullanici_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $ad = $row['isim'];
    $eposta = $row['email'];
    $telefon = $row['telefonnumarası'];
    $pozisyon = $row['pozisyon'];
} else {
    die("Kullanıcı bilgisi bulunamadı.");
}
$stmt->close();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profil Sayfası</title>
  <link rel="stylesheet" href="kullanicibilgi.css?v=<?php echo time(); ?>">
</head>
<body>

    <!-- Hamburger Menü İkonu -->
    <div class="menu-toggle" onclick="toggleMenu()">
      <span class="bar"></span>
      <span class="bar"></span>
      <span class="bar"></span>
    </div>

      <!-- Açılır Menü -->
<div class="sidebar" id="sidebar">
  <?php include 'sidebar.php'; ?>
</div>

    
  <!-- Üst Çubuk -->
  <div class="header" id="header">
    <img src="logo.png" alt="Logo">
  </div>

  <div class="profile-container">
    <h2>BİLGİLERİM</h2>
    <div class="info">
      <label for="Ad Soyad">Ad:</label>
      <input type="text" id="ad" value="<?php echo htmlspecialchars($ad); ?>" disabled>
    </div>
    <div class="info">
      <label for="eposta">E-Posta:</label>
      <input type="email" id="eposta" value="<?php echo htmlspecialchars($eposta); ?>" disabled>
    </div>
    <div class="info">
      <label for="telefon">Telefon:</label>
      <input type="tel" id="telefon" value="<?php echo htmlspecialchars($telefon); ?>" disabled>
    </div>
    <div class="info">
      <label for="pozisyon">Pozisyon:</label>
      <input type="text" id="pozisyon" value="<?php echo htmlspecialchars($pozisyon); ?>" disabled>
    </div>
    <div class="info">
      <label for="sifre">Yeni Şifre (Aynı kalacaksa boş bırakın):</label>
      <input type="password" id="sifre" placeholder="Yeni şifreniz" disabled>
    </div>
    <button id="duzenle-btn" onclick="enableEditing()">Düzenle</button>
    <button id="kaydet-btn" onclick="saveChanges()" style="display: none;">Kaydet</button>
</div>

  <!-- JavaScript -->
  <script>
    function toggleMenu() {
      var sidebar = document.getElementById('sidebar');
      var toggle = document.querySelector('.menu-toggle');
      sidebar.classList.toggle('active');
      toggle.classList.toggle('active');
  }
 
    // Profil düzenleme
    function enableEditing() {
      document.querySelectorAll('.info input').forEach(input => {
        input.disabled = false;
      });
      document.getElementById('duzenle-btn').style.display = 'none';
      document.getElementById('kaydet-btn').style.display = 'inline-block';
    }

    function saveChanges() {
    const ad = document.getElementById('ad').value;
    const eposta = document.getElementById('eposta').value;
    const telefon = document.getElementById('telefon').value;
    const pozisyon = document.getElementById('pozisyon').value;
    const sifre = document.getElementById('sifre').value;

    // AJAX ile verileri gönder
    fetch('update_profile.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ ad, eposta, telefon, pozisyon, sifre })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Bilgiler başarıyla güncellendi!");
            document.querySelectorAll('.info input').forEach(input => {
                input.disabled = true;
            });
            document.getElementById('sifre').value = ''; // Şifre alanını temizle
            document.getElementById('duzenle-btn').style.display = 'inline-block';
            document.getElementById('kaydet-btn').style.display = 'none';
        } else {
            alert(data.message || "Güncelleme sırasında bir hata oluştu.");
        }
    })
    .catch(error => console.error('Hata:', error));
}
  </script>
</body>
</html>
