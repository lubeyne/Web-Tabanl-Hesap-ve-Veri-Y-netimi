<?php
// Veritabanı bağlantı bilgileri
$host = 'localhost';
$dbname = 'calisan_sistemi';
$username = 'root';
$password = ''; // Yerel veritabanı şifreniz (genelde boştur)

// MySQLi bağlantısı
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// PDO bağlantısı
try {
    $conn_pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Hata
}

// SMTP E-posta Gönderim Ayarları
// NOT: E-posta gönderme işlevinin çalışması için geçerli bir SMTP kullanıcı adı ve Uygulama Şifresi (App Password) girilmelidir.
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'epostaniz@gmail.com');        // SMTP e-posta adresiniz
define('SMTP_PASS', 'uygulama-sifresi-buraya');   // Gmail'den alınan 16 haneli uygulama şifresi
define('SMTP_FROM', 'epostaniz@gmail.com');
define('SMTP_FROM_NAME', 'Şirket Sistem Yöneticisi');
?>
